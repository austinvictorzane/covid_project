# Got the data from https://data.bls.gov/cgi-bin/dsrv
# It output a large txt page that I copied and pasted
# Now I need to get rid of all the extra text

Data = read.table("4_27_2020_test_counties.txt", sep = "\n",  row.names = NULL)
